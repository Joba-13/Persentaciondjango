# Proyecto Universidad con aplicación Alumnos

Proyecto asociado a la guía de introducción a Django. Incluye la aplicación `alumnos`, el modelo `Alumno`, una vista de listado y administración mediante Django Admin. No incluye `env` o `.venv`, porque cada usuario debe crear su propio entorno virtual.

## Ejecución en Windows PowerShell

```powershell
cd Universidad_Alumnos_Django
py -m venv .venv
Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process
.\.venv\Scripts\Activate.ps1
py -m pip install --upgrade pip
pip install -r requirements.txt
py manage.py migrate
py manage.py runserver
```

Abrir: <http://127.0.0.1:8000/alumnos/index/>

## Ejecución en macOS o Linux

```bash
cd Universidad_Alumnos_Django
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

Abrir: <http://127.0.0.1:8000/alumnos/index/>

## Atributos del modelo Alumno

- `rut`: identificador único del alumno.
- `nombres`, `apellido_paterno` y `apellido_materno`.
- `correo_institucional`: correo único.
- `carrera`: programa académico cursado.
- `fecha_ingreso`: fecha de incorporación a la universidad.
- `activo`: indica si mantiene matrícula activa.

Para detener el servidor, presionar `Ctrl + C`. Para salir del entorno virtual, ejecutar `deactivate`.
