from django.shortcuts import render
from .models import Alumno
import matplotlib.pyplot as plt
import base64
from io import BytesIO
import matplotlib
from django.shortcuts import render, redirect, get_object_or_404
from .forms import AlumnoForm
from pathlib import Path
import csv
from collections import Counter, defaultdict

RUTA_CSV = Path(__file__).resolve().parent / "datos" / "datos.csv"

def leer_csv():
    with open(RUTA_CSV, newline="", encoding="utf-8-sig") as archivo:
        return list(csv.DictReader(archivo))

def index(request):
    alumnos = Alumno.objects.all().order_by("apellido_paterno", "nombres")
    return render(request, "alumnos/index.html", {"alumnos": alumnos})

matplotlib.use("Agg") # Dibujar sin abrir una ventana gráfica
def grafico1(request):
    # Dataset del ejemplo: número de alumnos por asignatura
    asignaturas = ["Python", "Bases de datos", "Django", "Redes"]
    cantidades = [18, 14, 21, 11]
    # Crear el gráfico de barras a partir de ambas listas
    figura, eje = plt.subplots(figsize=(8, 4.5))
    barras = eje.bar(asignaturas, cantidades, color="#2874A6")
    eje.set_title("Alumnos por asignatura")
    eje.set_xlabel("Asignatura")
    eje.set_ylabel("Cantidad de alumnos")
    eje.set_ylim(0, max(cantidades) + 5)
    eje.bar_label(barras, padding=3)
    figura.tight_layout()
    # Convertir la imagen PNG a texto para enviarla a HTML
    buffer = BytesIO()
    figura.savefig(buffer, format="png", dpi=120)
    plt.close(figura)
    buffer.seek(0)
    grafico = base64.b64encode(buffer.getvalue()).decode("utf-8")
    buffer.close()
    contexto = {"grafico": grafico}
    return render(request, "alumnos/grafico1.html", contexto)
def grafico2(request):
    # Dataset: asistencia semanal a un taller
    semanas = [1, 2, 3, 4, 5]
    asistentes = [12, 16, 14, 20, 24]
    figura, eje = plt.subplots(figsize=(8, 4.5))
    eje.plot(semanas, asistentes, marker="o", color="#2874A6", linewidth=2)
    eje.set_title("Asistencia semanal al taller")
    eje.set_xlabel("Semana")
    eje.set_ylabel("Cantidad de asistentes")
    eje.set_xticks(semanas)
    eje.grid(True, alpha=0.3)
    figura.tight_layout()
    buffer = BytesIO()
    figura.savefig(buffer, format="png", dpi=120)
    plt.close(figura)
    buffer.seek(0)
    grafico = base64.b64encode(buffer.getvalue()).decode("utf-8")
    buffer.close()
    return render(request, "alumnos/grafico2.html", {"grafico": grafico})   
def grafico3(request):
    # Dataset: horas de estudio y notas de ocho estudiantes
    horas = [1, 2, 2, 3, 4, 5, 6, 7]
    notas = [2.8, 3.4, 4.0, 4.2, 5.1, 5.0, 6.2, 6.5]
    figura, eje = plt.subplots(figsize=(8, 4.5))
    eje.scatter(horas, notas, color="#1E8449", s=80)
    eje.set_title("Horas de estudio y notas")
    eje.set_xlabel("Horas de estudio")
    eje.set_ylabel("Nota")
    eje.set_ylim(1, 7)
    eje.grid(True, alpha=0.3)
    figura.tight_layout()
    buffer = BytesIO()
    figura.savefig(buffer, format="png", dpi=120)
    plt.close(figura)
    buffer.seek(0)
    grafico = base64.b64encode(buffer.getvalue()).decode("utf-8")
    buffer.close()
    return render(request, "alumnos/grafico3.html", {"grafico": grafico})
def grafico4(request):
    # Dataset: alumnos inscritos por actividad
    actividades = ["Programación", "Robótica", "Diseño", "Redes"]
    inscritos = [12, 8, 6, 4]
    figura, eje = plt.subplots(figsize=(7, 5))
    eje.pie(inscritos, labels=actividades, autopct="%1.1f%%",
        startangle=90, colors=["#2874A6", "#1E8449", "#F4D03F", "#AF7AC5"])
    eje.set_title("Inscripciones por actividad")
    eje.axis("equal") # Mantener el círculo sin deformaciones
    figura.tight_layout()
    buffer = BytesIO()
    figura.savefig(buffer, format="png", dpi=120)
    plt.close(figura)
    buffer.seek(0)
    grafico = base64.b64encode(buffer.getvalue()).decode("utf-8")
    buffer.close()
    return render(request, "alumnos/grafico4.html", {"grafico": grafico})  

def alumno_crear(request):
    if request.method == "POST":
        form = AlumnoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("alumnos:index")
    else:
        form = AlumnoForm()
    contexto = {"form": form, "titulo": "Nuevo alumno"}
    return render(request, "alumnos/alumno_form.html", contexto) 

def alumno_editar(request, pk):
    alumno = get_object_or_404(Alumno, pk=pk)
    if request.method == "POST":
        form = AlumnoForm(request.POST, instance=alumno)
        if form.is_valid():
            form.save()
            return redirect("alumnos:index")
    else:
        form = AlumnoForm(instance=alumno)
    contexto = {"form": form, "titulo": "Editar alumno"}
    return render(request, "alumnos/alumno_form.html", contexto)

def alumno_eliminar(request, pk):
    alumno = get_object_or_404(Alumno, pk=pk)
    if request.method == "POST":
        alumno.delete()
        return redirect("alumnos:index")
    return render(
        request, "alumnos/alumno_confirmar_eliminar.html",
        {"alumno": alumno},
    )

def graficoDispersion(request):
    filas = leer_csv()
    puntos = [{"x": float(fila["Hours_Worked_Per_Week"]),
            "y": float(fila["Work_Life_Balance_Rating"]),}
        for fila in filas]
    configuracion = {
        "type": "scatter",
        "data": {
            "datasets": [{
                "label": "Cada punto representa un trabajador",
                "data": puntos,
                "backgroundColor": "#c0392b",}],},
        "options": {
            "plugins": {
                "legend": {"display": False},
                "tooltip": {
                    "enabled": False,},},
            "scales": {
                "x": {"title": {
                        "display": True,
                        "text": "Horas trabajadas por semana",},},
                "y": {"title": {
                        "display": True,
                        "text": "Calificación del equilibrio vida-trabajo",},},},},}
    return render(request, "alumnos/grafico.html", {
        "titulo": "Horas trabajadas y equilibrio vida-trabajo",
        "explicacion": "Cada punto representa un trabajador.", "datos_grafico": configuracion,})

def graficoBarras(request):
    filas = leer_csv()
    cantidades = Counter(
        fila["Industry"] for fila in filas if fila.get("Industry"))
    configuracion = {
        "type": "bar",
        "data": {
            "labels": list(cantidades.keys()),
            "datasets": [{
                "label": "Cantidad de trabajadores",
                "data": list(cantidades.values()),
                "backgroundColor": "#c0392b",}],},
        "options": {
            "plugins": {
                "legend": {"display": False},
                "tooltip": {"enabled": False},},
            "scales": {
                "x": {
                    "title": {"display": True, "text": "Industria"},},
                "y": {
                    "beginAtZero": True,
                    "title": {"display": True, "text": "Cantidad de trabajadores"},},},},}
    return render(request, "alumnos/grafico.html", {
        "titulo": "Trabajadores por industria",
        "explicacion": "Compara la cantidad de trabajadores registrados en cada industria.",
        "datos_grafico": configuracion,})

def graficoLineas(request):
    filas = leer_csv()
    horas_por_edad = defaultdict(list)
    for fila in filas:
        if fila.get("Age") and fila.get("Hours_Worked_Per_Week"):
            edad = int(fila["Age"])
            horas = float(fila["Hours_Worked_Per_Week"])
            horas_por_edad[edad].append(horas)
    edades = sorted(horas_por_edad.keys())
    promedios = [sum(horas_por_edad[edad]) / len(horas_por_edad[edad])
        for edad in edades]
    configuracion = {"type": "line",
        "data": {"labels": [str(edad) for edad in edades],
            "datasets": [{"label": "Promedio de horas semanales",
                "data": promedios, "borderColor": "#2874a6",
                "backgroundColor": "#2874a6", "tension": 0.3,}],},
        "options": {
            "plugins": {"legend": {"display": False},"tooltip": {"enabled": False},},
            "scales": {
                "x": {"title": {"display": True, "text": "Edad"},},
                "y": {"beginAtZero": True,
                    "title": {"display": True,
                        "text": "Promedio de horas trabajadas por semana",},},},},}
    return render(request, "alumnos/grafico.html", {
        "titulo": "Horas semanales promedio según edad",
        "explicacion": "Muestra el promedio de horas trabajadas por semana para cada edad.",
        "datos_grafico": configuracion,})

def listadoIndustria(request):
    filas_csv = leer_csv()
    cantidades = Counter(
        fila["Industry"]
        for fila in filas_csv
        if fila.get("Industry"))
    filas_tabla = [
        [industria, cantidad]
        for industria, cantidad in sorted(
            cantidades.items(),
            key=lambda elemento: elemento[1],
            reverse=True)]
    contexto = {
        "titulo": "Trabajadores por industria",
        "explicacion": (
            "La tabla muestra cuántos trabajadores pertenecen "
            "a cada industria."),
        "columnas": ["Industria", "Cantidad de trabajadores"],
        "filas": filas_tabla,}
    return render(request, "alumnos/listado.html", contexto)

def listadoHorasEdad(request):
    filas_csv = leer_csv()
    horas_por_edad = defaultdict(list)
    for fila in filas_csv:
        try:
            edad = int(float(fila["Age"]))
            horas = float(fila["Hours_Worked_Per_Week"])
        except (KeyError, ValueError):
            continue
        horas_por_edad[edad].append(horas)
    filas_tabla = [
        [edad, round(sum(horas) / len(horas), 1)]
        for edad, horas in sorted(horas_por_edad.items())
        if horas]
    contexto = {
        "titulo": "Horas trabajadas según edad",
        "explicacion": (
            "La tabla muestra el promedio de horas trabajadas segun diferentes edades."
        ),
        "columnas": ["Edad", "Promedio de horas por semana"],
        "filas": filas_tabla,
    }

    return render(request, "alumnos/listado.html", contexto)

def listadoEquilibrio(request):
    filas_csv = leer_csv()
    horas_por_calificacion = defaultdict(list)
    for fila in filas_csv:
        try:
            calificacion = int(float(fila["Work_Life_Balance_Rating"]))
            horas = float(fila["Hours_Worked_Per_Week"])
        except (KeyError, ValueError):
            continue

        horas_por_calificacion[calificacion].append(horas)

    filas_tabla = [
        [calificacion, len(horas), round(sum(horas) / len(horas), 1)]
        for calificacion, horas in sorted(horas_por_calificacion.items())
        if horas]
    contexto = {
        "titulo": "Equilibrio entre vida y trabajo",
        "explicacion": (
            "La tabla muestra cuántos trabajadores tienen cada "
            "calificación de equilibrio y sus horas semanales promedio."),
        "columnas": [
            "Calificación de equilibrio",
            "Cantidad de trabajadores",
            "Promedio de horas por semana"],
        "filas": filas_tabla,
    }
    return render(request, "alumnos/listado.html", contexto)

def pagina_listados(request):
    return render(request, "alumnos/pagina_listados.html")

def pagina_graficos(request):
    return render(request, "alumnos/pagina_graficos.html")

def graficoEdadExperiencia(request):
    filas_csv = leer_csv()
    puntos = []
    for fila in filas_csv:
        try:
            edad = float(fila["Age"])
            experiencia = float(fila["Years_of_Experience"])
        except (KeyError, ValueError):
            continue
        puntos.append({"x": edad, "y": experiencia,})
    configuracion = {
        "type": "scatter",
        "data": {"datasets": [{"label": "Trabajadores",
                "data": puntos,
                "backgroundColor": "rgba(40, 116, 166, 0.2)",
                "pointRadius": 2,}],},
        "options": {"plugins": {"legend": {"display": False},
                "tooltip": {"enabled": False},},
            "scales": {"x": {"title": {"display": True,
                        "text": "Edad (años)",},},
                "y": {"title": {"display": True,
                        "text": "Años de experiencia",},},},},}
    contexto = {"titulo": "Edad y años de experiencia",
        "explicacion": ("Cada punto representa a un trabajador. "
        "El gráfico compara su edad con sus años de experiencia."),
        "datos_grafico": configuracion,}
    return render(request, "alumnos/grafico.html", contexto)

