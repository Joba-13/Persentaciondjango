from django.urls import path
from . import views

app_name = "alumnos"

urlpatterns = [
    path("", views.index, name="index"),
    path("index/", views.index, name="index_page"),
    path("grafico1/", views.grafico1, name="grafico1"),
    path("grafico2/", views.grafico2, name="grafico2"),
    path("grafico3/", views.grafico3, name="grafico3"),
    path("grafico4/", views.grafico4, name="grafico4"),
    path("graficos/dispersion/", views.graficoDispersion, name="graficoDispersion"),
    path("nuevo/", views.alumno_crear, name="alumno_crear"),
    path("<int:pk>/editar/", views.alumno_editar, name="alumno_editar"),
    path("<int:pk>/eliminar/", views.alumno_eliminar, name="alumno_eliminar"),
    path("graficos/barras-csv/", views.graficoBarras, name="graficoBarras"),
    path("graficos/lineas-csv/",views.graficoLineas,name="graficoLineas"),
    path("listados/industria/",views.listadoIndustria,name="listadoIndustria"),
    path("listados/horas-edad/",views.listadoHorasEdad,name="listadoHorasEdad"),
    path("listados/equilibrio/",views.listadoEquilibrio,name="listadoEquilibrio"),
    path("listados/", views.pagina_listados, name="pagina_listados"),
    path("graficos/", views.pagina_graficos, name="pagina_graficos"),
    path("graficos/edad-experiencia/",views.graficoEdadExperiencia,name="graficoEdadExperiencia"),
    
]