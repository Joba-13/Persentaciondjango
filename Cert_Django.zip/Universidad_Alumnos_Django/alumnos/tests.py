from datetime import date

from django.test import TestCase

from .models import Alumno


class AlumnosViewTests(TestCase):
    def test_index(self):
        Alumno.objects.create(
            rut="12.345.678-5",
            nombres="Ana María",
            apellido_paterno="Pérez",
            apellido_materno="Soto",
            correo_institucional="ana.perez@universidad.cl",
            carrera="Ingeniería en Informática",
            fecha_ingreso=date(2026, 3, 2),
        )
        response = self.client.get("/alumnos/index/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Listado de alumnos")
        self.assertContains(response, "Ana María Pérez Soto")
