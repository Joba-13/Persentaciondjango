from django.db import models


class Alumno(models.Model):
    rut = models.CharField("RUT", max_length=12, unique=True)
    nombres = models.CharField(max_length=100)
    apellido_paterno = models.CharField(max_length=60)
    apellido_materno = models.CharField(max_length=60, blank=True)
    correo_institucional = models.EmailField(unique=True)
    carrera = models.CharField(max_length=120)
    fecha_ingreso = models.DateField()
    activo = models.BooleanField(default=True)

    class Meta:
        ordering = ["apellido_paterno", "apellido_materno", "nombres"]
        verbose_name = "alumno"
        verbose_name_plural = "alumnos"

    def __str__(self):
        return f"{self.rut} - {self.nombres} {self.apellido_paterno}"
